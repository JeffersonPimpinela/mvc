﻿namespace MvcWebIdentity.Services;

public interface ISeedUserClaimsInitial
{
    Task SeedUserClaims();
}
